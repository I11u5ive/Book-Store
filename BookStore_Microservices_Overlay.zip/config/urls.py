from django.contrib import admin
from django.urls import include, path
from django.views.generic import RedirectView

from debug_toolbar.toolbar import debug_toolbar_urls
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView, TokenVerifyView

urlpatterns = [
    path("", RedirectView.as_view(url="/books/", permanent=False), name="home"),
    path("admin/", admin.site.urls),
    path("books/", include("books.urls")),
    path("accounts/", include("users.urls")),
    path("cart/", include("shop_orders.urls")),
    path("i18n/", include("django.conf.urls.i18n")),
    path("api/", include("api.urls")),
    path("api/warehouse/", include("config.warehouse_urls")),
    path("api/token/", TokenObtainPairView.as_view(), name="token_obtain_pair"),
    path("api/token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),
    path("api/token/verify/", TokenVerifyView.as_view(), name="token_verify"),
    path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
    path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger-ui"),
] + debug_toolbar_urls()
